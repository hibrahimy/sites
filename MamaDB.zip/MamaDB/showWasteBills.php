<?php
include('config.php');
$query_bills = "SELECT * FROM `bills_waste`";
$res_qu = $con->query($query_bills);
?>
<div class="alert alert-success" role="alert">
  <h1 class='h1' style='text-align: center;'>بل های فاضلاب کرایه نشین ها</h1>
</div>
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">ای دی</th>
      <th scope="col">اسم مکمل</th>
      <th scope="col">شماره تذکره</th>
      <th scope="col">شماره اپارتمان</th>
      <th scope="col">تعدادنفر</th>
      <th scope="col">تعداد روز</th>
      <th scope="col">مقدارپرداخت</th>
      <th scope="col">دوره</th>
      <th scope="col">تاریخ صدوربل</th>
      <th scope="col">اختیارات</th>
    </tr>
  </thead>
  <tbody>
  <?php

  
  while($result = $res_qu->fetch_assoc()):
    echo "<tr>
      <td>$result[id]</td>
      <td>$result[fname]</td>
      <td>$result[nid]</td>
      <td>$result[appnum]</td>
      <td>$result[persons]</td>
      <td>$result[days]</td>
      <td>$result[payment] اففانی</td>
      <td>$result[term]</td>
      <td>$result[timestamp]</td>
      <td>
      <a href='?p=del&id=$result[id]' style='color:red'>X</a>
      ---
      <a href='?p=pr&id=$result[id]'style='color:blue'>P</a>
      </td>
    </tr>";
  endwhile;
  ?>


    <!-- <td>
    <?php 
      // if($result[paid]==1)
      //   echo "بلی";
      // else
      //   echo "نخیر";  
      // echo "</td>";
    ?> -->
  
  </tbody>
</table>