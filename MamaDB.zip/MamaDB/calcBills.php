<?php
$con->query('SET CHARACTER SET utf8');
$q = "SELECT * FROM `tenants` WHERE `status`=1";
$runq = $con->query($q);

if(isset($_POST['calcs'])){
  $money = trim($_POST['money']);
  $dy = "SELECT SUM(t_perce) AS tp FROM `tenants` WHERE `status`=1";
  $tdy = $con->query($dy);
  $tdy = $tdy->fetch_assoc()['tp'];
  
  $r = "SELECT * FROM `tenants` WHERE `status`=1";
  $rr = $con->query($r);
  
  while($re = $rr->fetch_assoc()):
    $pay = round(($money/$tdy)*$re['t_perce']);
    $con->query('SET CHARACTER SET utf8');

    $payed = "UPDATE `tenants` SET `payment`=$pay WHERE `id`= $re[id];";
    $con->query($payed);

    $host1  = $_SERVER['HTTP_HOST'];
    $uri1   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
    $extra1 = '?p=calc&success';
    // echo "<a href='http://$host$uri/$extra' >برگشت به صفحه اصلی</a>";
    header("Location: http://$host1$uri1/$extra1");

  endwhile;
  // $con->query('SET CHARACTER SET utf8');
  // $q = "SELECT * FROM `tenants` WHERE `status`=1";
  // $runq = $con->query($q);
  
}

if(isset($_POST['rec_bills'])){
  if(!empty($_POST['term'])&&!empty($_POST['reason'])){
  $term = $_POST['term'];
  $reason = $_POST['reason'];
  $selq = "SELECT * FROM `tenants` WHERE `status`=1";
  $tenantstbl = $con->query($selq);

  while($tenant=$tenantstbl->fetch_assoc()):

    $bills = $con->query("SELECT * FROM `$reason` WHERE `term`=$term AND `nid`='$tenant[nid]'");
    if($bills->fetch_all()==null){
      $insert_Q = "INSERT INTO `$reason`(`fname`,`nid`,`appnum`,`days`,`persons`,
      `p_perce`,`d_perce`,`t_perce`,`payment`,`paid`,`term`)
      VALUES ('$tenant[fname]','$tenant[nid]',$tenant[appnum],$tenant[days],
      $tenant[pnumber],$tenant[p_perce],$tenant[d_perce],$tenant[t_perce],
      $tenant[payment],0,$term)";
      $con->query($insert_Q);
      echo "Error Occured " . $con->error;
      // $host  = $_SERVER['HTTP_HOST'];
      // $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
      // $extra = '?p=calc&added';
      // header("Location: http://$host$uri/$extra");

    }else{
      $host  = $_SERVER['HTTP_HOST'];
      $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
      $extra = '?p=calc&failed';
      header("Location: http://$host$uri/$extra");
    }

    


  endwhile;
  
 
  //  print_r($checks->fetch_all());
  //   $que_tenants = "SELECT * FROM `tenants`";
  //   $res_sydb = $con->query($que_tenants);
  //   $errors = [];
  //   while($result = $res_sydb->fetch_assoc()):
  //   $ins_query = "INSERT INTO `$reason`(`fname`, `nid`, `appnum`, `days`,
  //   `persons`, `payment`, `paid`, `term`) 
  //   VALUES ('$result[fname]','$result[nid]',$result[appnum],$result[days],
  //   $result[pnumber],$result[payment],0,$term)";
  //   $con->query($ins_query);
  // endwhile;
  // $host  = $_SERVER['HTTP_HOST'];
  // $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
  // $extra = '?p=calc&succ';
  // header("Location: http://$host$uri/$extra");
}else{
  // // Please fill both inputs trm and reason
  $host  = $_SERVER['HTTP_HOST'];
  $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
  $extra = '?p=calc&failed';
   header("Location: http://$host$uri/$extra");
  // echo "http://$host$uri/$extra";
}
}
?>
<div class="alert alert-success" role="alert">
  <h1 class='h1' style='text-align: center;'>محاسبه بل های کرایه نشین ها</h1>
</div>
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">ای دی</th>
      <th scope="col">اسم مکمل</th>
      <th scope="col">شماره اپارتمان</th>
      <!-- <th scope="col">تعدادنفر</th> -->
      <th scope="col">فیصدی تعدادنفر</th>
      <th scope="col">فیصدی تعدادروز</th>
      <th scope="col">مجوعه فیصدیها</th>
      <th scope="col">نوعیت بل</th>
      <th scope="col">مقدارقابل تادیه</th>
    </tr>
  </thead>
  <tbody>
  <?php
  while($result = $runq->fetch_assoc()):
    
    //       <td>$result[pnumber]</td>
    echo "<tr>
      <td>$result[id]</td>
      <td>$result[fname]</td>
      <td>$result[appnum]</td>

      <td>$result[p_perce]%</td>
      <td>$result[d_perce]%</td>
      <td>$result[t_perce]</td>
      <td>$result[reason]</td>
      <td>$result[payment] افغانی</td>
    </tr>";
  endwhile;
  ?>
  <tr>
  <form action="?p=calc" method="post">
  <td><mat-form-field>
    <input matInput name='money' placeholder="قیمت" value="">
  </mat-form-field>
  </td>
  <td>مقدارمصرف</td>
  

  
  <td>
  <mat-form-field>
    <input matInput name='calcs' class="btn btn-primary" type="submit" value="محاسبه">
  </mat-form-field>
  </form>
  </td>
  </tr>
  <tr>
  <form action="?p=calc" method="post">
  <td><mat-form-field>

  <input type='number' matInput id='trm' class="form-control" name='term' placeholder="دوره" value="" />
    <!-- <select matInput id='trm' class="form-control" name='term' placeholder="دوره" value="">
      <script>
        for (let i =1; i<21; i++){
          $('#trm').append("<option value="+ i +">" + i +"</option>");
        }
      </script>
    </select> -->
  </mat-form-field>
  </td>
  <td>دوره</td>
  <td><mat-form-field>
    <select matInput id='reason' class="form-control" name='reason' placeholder="نوعیت بل">
     <option value="bills_waste">فاضلاب</option>
     <option value="bills_water">اب</option>
    </select>
  </mat-form-field>
  </td>
  <td>نوعیت بل</td>
  <td></td>
    <td>
      <mat-form-field>
      <input matInput name='rec_bills' class="btn btn-warning" type="submit" value="بل را ذخیره کنید">
      </mat-form-field>
    </td>
  </form>
  </tr>
  </tbody>
</table>
<?php
       if(isset($_GET['success'])){

       ?>
        <div class="bs-example">
          <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong> . . . .  </strong> محاسبه موفقانه صورت گرفت.. .. . . . 
          </div>
        </div>
        
        <?php
      
       }elseif(isset($_GET['failed'])){
        ?>

        <div class="bs-example">
          <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong> . . . .  </strong> این بل قبلا درج شده است لطفا-- دوره  ویا  نوعیت بل را تغیردهید.. .. . . . 
          </div>
        </div>

        <?php
       }elseif(isset($_GET['succ'])){
        ?>

        <div class="bs-example">
          <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong> . . . .  </strong> بل موفقانه واردسیستم گردید.. .. . . . 
          </div>
        </div>

        <?php
       }elseif(isset($_GET['added'])){
        ?>

        <div class="bs-example">
          <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert">&times;</a>
            <strong> . . . .  </strong> بل موفقانه واردسیستم گردید.. .. . . . 
          </div>
        </div>

        <?php
       }
      
       ?>