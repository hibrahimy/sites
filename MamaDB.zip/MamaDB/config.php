<?php
// Host, User, Password, DB
$con = new mysqli('localhost','sehi','admin','mamadb');
$con->query('SET CHARACTER SET utf8');
?>